class FullClass
{
    List<ClassTable> fullClass;

    FullClass( List<ClassTable> fullClass){
        this.fullClass = fullClass;
    }
}