struct FunctionTable
{
    string name;
    string type;
    int scope;


    FunctionTable(string name,string type,int scope)
   {
    this.name = name;
    this.type = type;
    this.scope = scope;

   }
}